"use client";

import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Check, ExternalLink, MessageCircle } from "lucide-react";
import Image from "next/image";
import { getWhatsAppUrl, siteConfig } from "@/lib/config";

export function Hero() {
  const shouldReduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const y = useTransform(
    scrollYProgress,
    [0, 1],
    [0, shouldReduceMotion ? 0 : 90],
  );
  const whatsAppUrl = getWhatsAppUrl();

  return (
    <section
      id="inicio"
      className="relative isolate flex min-h-[100svh] overflow-hidden bg-white text-zinc-950"
    >
      <motion.div className="absolute inset-0 -z-20" style={{ y }}>
        <Image
          src={siteConfig.hero.backgroundImage}
          alt={siteConfig.hero.backgroundAlt}
          fill
          priority
          loading="eager"
          sizes="100vw"
          className="object-cover opacity-38"
        />
      </motion.div>
      <div className="absolute inset-0 -z-10 bg-white/28" />
      <div className="absolute inset-y-0 left-0 -z-10 w-full bg-gradient-to-r from-white via-white/92 to-white/40" />
      <div className="absolute inset-x-0 bottom-0 -z-10 h-56 bg-white" />

      <div className="mx-auto grid w-full max-w-7xl items-center gap-10 px-5 pb-12 pt-32 sm:px-6 lg:grid-cols-[minmax(0,1fr)_430px] lg:px-8 lg:py-28">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-4xl"
        >
          <p className="mb-5 inline-flex items-center rounded-full border border-red-100 bg-white px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[var(--accent)] shadow-sm">
            {siteConfig.hero.eyebrow}
          </p>
          <h1 className="max-w-[12ch] text-balance text-[2.55rem] font-semibold leading-[1.02] tracking-normal text-zinc-950 sm:max-w-4xl sm:text-6xl sm:leading-[0.98] lg:text-7xl">
            {siteConfig.hero.title}
          </h1>
          <p className="mt-6 max-w-[30ch] text-pretty text-lg leading-8 text-zinc-700 sm:max-w-[32rem] sm:text-xl">
            {siteConfig.hero.subtitle}
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <motion.a
              href={whatsAppUrl}
              target="_blank"
              rel="noreferrer"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex h-[52px] items-center justify-center gap-2 rounded-full bg-[var(--accent)] px-6 text-sm font-semibold text-white transition-colors hover:bg-[var(--accent-dark)]"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              Chamar no WhatsApp
            </motion.a>
            <motion.a
              href="#servicos"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex h-[52px] items-center justify-center rounded-full border border-zinc-200 bg-white px-6 text-sm font-semibold text-zinc-950 shadow-sm transition-colors hover:border-zinc-300 hover:bg-zinc-50"
            >
              Ver Serviços
            </motion.a>
            <motion.a
              href={siteConfig.contact.instagramUrl}
              target="_blank"
              rel="noreferrer"
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex h-[52px] items-center justify-center gap-2 rounded-full border border-red-100 bg-white px-6 text-sm font-semibold text-[var(--accent)] shadow-sm transition-colors hover:border-[var(--accent)] hover:bg-red-50"
            >
              <ExternalLink className="h-4 w-4" aria-hidden="true" />
              Acompanhar no Instagram
            </motion.a>
          </div>

          <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 shadow-sm">
            <ExternalLink className="h-4 w-4 text-[var(--accent)]" />
            {siteConfig.brand.instagramHandle}
          </div>

          <ul className="mt-7 grid max-w-xl gap-3 text-sm text-zinc-700 sm:grid-cols-3">
            {siteConfig.hero.bio.map((item) => (
              <li key={item} className="flex items-center gap-2">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[var(--accent)] text-white">
                  <Check className="h-3 w-3" aria-hidden="true" />
                </span>
                <span>{item}</span>
              </li>
            ))}
          </ul>

          <a
            href="#confianca"
            className="mt-12 hidden w-fit items-center gap-3 text-sm text-zinc-600 transition-colors hover:text-zinc-950 sm:inline-flex"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full border border-zinc-200 bg-white">
              <ArrowDown className="h-4 w-4" aria-hidden="true" />
            </span>
            Atendimento local, rápido e especializado
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30, scale: 0.98 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1], delay: 0.12 }}
          className="hidden lg:block"
        >
          <div className="relative aspect-[4/5] overflow-hidden rounded-lg border border-zinc-200 bg-white p-2 shadow-xl shadow-zinc-950/10">
            <Image
              src={siteConfig.hero.sideImage}
              alt={siteConfig.hero.sideImageAlt}
              fill
              priority
              loading="eager"
              sizes="430px"
              className="rounded-md object-cover"
            />
          </div>
          <div className="mt-4 flex items-center justify-between border-t border-zinc-200 pt-4 text-sm text-zinc-600">
            <span>{siteConfig.contact.shortAddress}</span>
            <span className="text-[var(--accent)]">Plantão 24h</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
